package com.example.spring.batch;

public record Person(String firstName, String lastName) {
}
