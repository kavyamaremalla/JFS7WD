package org.example;

import java.sql.*;

public class Main {
    public static void main(String[] args) throws SQLException {

        String query = "select * from employee";

        Connection connection = DriverManager
                .getConnection("jdbc:mysql://localhost/schools?user=root&password=Password!123");

        PreparedStatement preparedStatement = connection.prepareStatement(query);
        ResultSet resultSet = preparedStatement.executeQuery();

        while (resultSet.next()){
            System.out.println(resultSet.getInt(1) + " " + resultSet.getString(3));
        }
    }
}