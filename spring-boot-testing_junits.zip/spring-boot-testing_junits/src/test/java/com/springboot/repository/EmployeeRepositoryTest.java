package com.springboot.repository;

public class EmployeeRepositoryTest {
}
