package com.example.springdatajpa.service;

import com.example.springdatajpa.entity.User;

import java.util.List;

public interface UserService {

    User createUser(User user);

    List<User> getAllUsers();

    User getUserById(Long userId);

    User updateUser(User user);

    void deleteUser(Long userId);

}
