package com.example.springdatajpa.service.impl;

import com.example.springdatajpa.dto.UserDto;
import com.example.springdatajpa.entity.User;
import com.example.springdatajpa.exception.EmailAlreadyExistsException;
import com.example.springdatajpa.exception.ResourceNotFoundException;
import com.example.springdatajpa.mapper.UserMapper;
import com.example.springdatajpa.repository.UserRepository;
import com.example.springdatajpa.service.UserService;
import lombok.AllArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class UserServiceImpl implements UserService {

    //    @Autowired
    private UserRepository userRepository;

//    private UserMapper userMapper;

    private ModelMapper modelMapper;

    @Override
    public UserDto createUser(UserDto userDto) {

//        User savedUser = userRepository.save(userMapper.mapToUser(userDto));//obj saved to db
//
//        return userMapper.mapToUserDto(savedUser);

        User user = modelMapper.map(userDto, User.class);

        Optional<User> existingEmail = userRepository.findByEmail(user.getEmail());

        if (existingEmail.isPresent()) {
            throw new EmailAlreadyExistsException("Email already exists with us. Please select a new email or login!");
        }

        return modelMapper.map(userRepository.save(user), UserDto.class);

    }

    @Override
    public List<UserDto> getAllUsers() {
        List<User> userList = userRepository.findAll();
        return userList.stream().map(UserMapper::mapToUserDto).collect(Collectors.toList());
    }

    @Override
    public UserDto getUserById(Long userId) {
        return UserMapper.mapToUserDto(userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User", "id", userId)));
    }

    @Override
    public UserDto updateUser(UserDto userDto) {

        User existingUser = userRepository.findById(userDto.getId())
                .orElseThrow(() -> new ResourceNotFoundException("User", "id", userDto.getId()));

        existingUser.setFirstName(userDto.getFirstName());
        existingUser.setLastName(userDto.getLastName());
        existingUser.setEmail(userDto.getEmail());

        //userRepository.save(existingUser)

        return null;
    }

    @Override
    public void deleteUser(Long userId) {

        userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User", "id", userId));

        userRepository.deleteById(userId);
    }
}
