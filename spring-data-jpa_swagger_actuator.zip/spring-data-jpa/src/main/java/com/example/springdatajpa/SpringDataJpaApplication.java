package com.example.springdatajpa;

import com.example.springdatajpa.dto.UserDto;
import com.example.springdatajpa.entity.User;
import io.swagger.v3.oas.annotations.ExternalDocumentation;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Contact;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.info.License;
import org.modelmapper.ModelMapper;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.core.task.TaskExecutor;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

@SpringBootApplication

@OpenAPIDefinition(
		info = @Info(
				title = "User Management",
				description = "Basic CRUD Operations for a User",
				contact = @Contact(
						name = "John Doe",
						email = "johnd@gmail.com",
						url = "https://wwww.google.com"
				),
				license = @License(name = "Backed up by : Apache 2.0")

		), externalDocs = @ExternalDocumentation(
		description = "CRUD Operations"
)
)

//@EnableAsync
public class SpringDataJpaApplication {

//	@Bean
//	public TaskExecutor taskExecutor(){
//		return new ThreadPoolTaskExecutor();
//	}
//
//	@Async
//	//method..

	@Bean
	public ModelMapper modelMapper(){
//		ModelMapper mapper = new ModelMapper();
//		mapper.createTypeMap(UserDto.class, User.class).addMapping(UserDto::getId,User::setId);
		return new ModelMapper();
	}

	public static void main(String[] args) {
		SpringApplication.run(SpringDataJpaApplication.class, args);
	}

}
