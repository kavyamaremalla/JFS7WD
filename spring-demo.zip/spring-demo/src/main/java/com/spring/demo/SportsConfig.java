package com.spring.demo;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
@ComponentScan("com.spring.demo")
@PropertySource("sports.properties")
public class SportsConfig {

    @Bean
    public WishService badWishService(){
        return new BadWishService();
    }

    @Bean
    public Coach swimCoach(){
        return new SwimCoach_ThirdPartyJars(badWishService());
    }
}
