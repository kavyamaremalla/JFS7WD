package com.spring.demo;

public interface Coach {

    String getDailyWorkOut();

    String getDailyWish();
}
