package com.spring.demo;

import org.springframework.beans.factory.annotation.Autowired;

public class SwimCoach_ThirdPartyJars implements Coach{

    private WishService wishService;

    @Autowired
    public SwimCoach_ThirdPartyJars(WishService wishService) {
        this.wishService = wishService;
    }

    @Override
    public String getDailyWorkOut() {
        return "Swimming Practice";
    }

    @Override
    public String getDailyWish() {
        return wishService.getWish();
    }
}
