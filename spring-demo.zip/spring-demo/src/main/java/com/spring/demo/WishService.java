package com.spring.demo;

public interface WishService {

     String getWish();
}
