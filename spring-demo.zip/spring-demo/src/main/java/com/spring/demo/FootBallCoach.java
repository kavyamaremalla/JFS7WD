package com.spring.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

@Component("myFootBallCoach")
@Scope(value = BeanDefinition.SCOPE_PROTOTYPE)
public class FootBallCoach implements Coach{

//    @Autowired
//@Qualifier("happyWishService")
    private WishService wishService;

    @Value("${email}")
    private String email;

    @Autowired
    public FootBallCoach(WishService wishService){
        this.wishService = wishService;
    }

//   @Autowired
    public void setWishService(WishService wishService){
        this.wishService = wishService;
    }

    public WishService getWishService() {
        return wishService;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDailyWorkOut(){
        return "Kicking Practice";
    }

    @Override
    public String getDailyWish() {
        return wishService.getWish();
    }


    @PostConstruct
    public void startUpMethod(){
        System.out.println("Object started");
    }

    @PreDestroy
    public void destroyMethod(){
        System.out.println("destructed");
    }
}
