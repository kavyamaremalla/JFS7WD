package com.spring.demo;

import org.springframework.stereotype.Component;

@Component("myCricketCoach")
public class CricketCoach implements Coach{

    private WishService wishService;

    public String getDailyWorkOut(){
        return "Batting Practice";
    }

    @Override
    public String getDailyWish() {
        return wishService.getWish();
    }
}
