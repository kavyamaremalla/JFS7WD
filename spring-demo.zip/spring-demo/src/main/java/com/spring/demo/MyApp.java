package com.spring.demo;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MyApp {
    public static void main(String[] args) {

//        Coach cricketCoach = new CricketCoach();
//        System.out.println(cricketCoach.getDailyWorkOut());
//
//
//        FootBallCoach footBallCoach = new FootBallCoach();
//        footBallCoach.setWishService(new HappyWishService());
//        System.out.println(footBallCoach.getDailyWish());

//        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");

        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(SportsConfig.class);
//        FootBallCoach footballCoach = context.getBean("myFootBallCoach", FootBallCoach.class);
//
//        System.out.println(footballCoach.getDailyWorkOut());
//        System.out.println(footballCoach.getDailyWish());
//        System.out.println(footballCoach.getEmail());
//
//        //singleton
//
//        Coach coach1 = context.getBean("myFootBallCoach",Coach.class);
//        Coach coach2 = context.getBean("myFootBallCoach",Coach.class);
//
//        System.out.println(coach1);
//        System.out.println(coach2);

//        SwimCoach_ThirdPartyJars  swimCoach = new SwimCoach_ThirdPartyJars(new BadWishService());
//        System.out.println(swimCoach.getDailyWish());

        Coach swimCoach = context.getBean("swimCoach", Coach.class);
        System.out.println(swimCoach.getDailyWish());
        context.close();
    }
}