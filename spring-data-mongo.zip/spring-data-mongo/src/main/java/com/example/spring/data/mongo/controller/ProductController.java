package com.example.spring.data.mongo.controller;

import com.example.spring.data.mongo.dto.Product;
import com.example.spring.data.mongo.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class ProductController {

    @Autowired
    private ProductRepository repository;


    @PostMapping("addProduct")
    public String saveProduct(@RequestBody Product product){
        repository.save(product);
        return "Product Added Suucessfully";
    }

    @PostMapping("/addProductList")
    public String saveAllProducts(@RequestBody List<Product> productList){
        repository.saveAll(productList);
        return "product list save Successfully";
    }

    @GetMapping("/findAllProducts")
    public List<Product> getProductList(){
        return repository.findAll();
    }

    @DeleteMapping("/delete/{id}")
    public String deleteProduct(@PathVariable String id){
        repository.deleteById(id);
        return  "Deleted Successfully";
    }
}
