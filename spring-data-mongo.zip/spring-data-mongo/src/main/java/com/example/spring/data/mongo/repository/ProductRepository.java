package com.example.spring.data.mongo.repository;

import com.example.spring.data.mongo.dto.Product;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface ProductRepository extends MongoRepository<Product, String> {
}
