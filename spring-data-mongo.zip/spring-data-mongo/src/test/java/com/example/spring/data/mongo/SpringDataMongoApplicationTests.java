package com.example.spring.data.mongo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDataMongoApplicationTests {

	@Test
	void contextLoads() {
	}

}
