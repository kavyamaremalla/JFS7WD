package com.boot.demo.service;

public interface StudentService {
}
