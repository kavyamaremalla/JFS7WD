package com.boot.demo.bean;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
//import org.apache.commons.logging.Log;
//import org.apache.commons.logging.LogFactory;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Student {

    private int id;

    private String firstName;

    private  String lastName;

//    private static Log log = LogFactory.getLog(Student.class);

//    public static void main(String[] args) {
//
//        Student student = new Student(1,"John", "Potter");
//        log.info("Tomcat is running & Student details are in normal mode: " + student.getId() + " " + student.getFirstName());
//        log.debug("Tomcat is running & Student details are in debug mode: " + student.getId() + " " + student.getFirstName());
//
//    }

}
