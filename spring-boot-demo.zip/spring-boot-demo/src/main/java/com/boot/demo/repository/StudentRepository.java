package com.boot.demo.repository;

public class StudentRepository {
}
