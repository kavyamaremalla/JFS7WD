package com.boot.demo.controller;

import com.boot.demo.bean.Student;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("api/student")
public class StudentController {

    static List<Student> studentList = new ArrayList<>();

    static {
        Student student1 = new Student(1, "John", "Doe"); // index is 0
        Student student2 = new Student(2, "Harry", "Potter"); // index is 1

        studentList.add(student1);
        studentList.add(student2);
    }

//    @GetMapping("call-app")
//    public String firstAPI(){
//        return "Hurray! This is your first API";
//    }

    @GetMapping("getStudent")
    public ResponseEntity<Object> getStudent() {
        Student student = new Student(4, "Ana", "Karen");
        return ResponseEntity.ok().body(student);
    }

    @GetMapping("getStudents")
    public ResponseEntity<List<Student>> getStudents() {
        return ResponseEntity.ok().body(studentList);
    }

    @GetMapping("getStudent/{id}") // id is 1
    public ResponseEntity<Student> getStudentById(@PathVariable("id") Integer studentId) {
        //select * from student where student_Id = 1 --> service to repo..
        Student student = studentList.get(studentId - 1); //0th index
        return ResponseEntity.ok().body(student);
    }

    @PostMapping("createStudent")
    public ResponseEntity<List<Student>> createStudent(@RequestBody Student student) {
        //{id : 3 , firstName : "Peter", lastName : "Parker"}
        //insert into student (columns names) values();
        student.setId(studentList.size() + 1);
        studentList.add(student);

        return new ResponseEntity<>(studentList, HttpStatus.CREATED);
    }

    @PutMapping("updateStudent/{id}")
    public ResponseEntity<Student> updateStudent(@RequestBody Student student, @PathVariable("id") Integer studentId) {
        //update student set() values() where id = 1

        studentList.set(studentId - 1, student);

        return ResponseEntity.ok(student);
    }

    @DeleteMapping("deleteStudent/{id}")
    public ResponseEntity<String> deleteStudent(@PathVariable("id") int studentId){
        //delete * from student where studentID = 1;

        studentList.remove(studentId - 1);

        return  new ResponseEntity<>("Student Deleted successfully" , HttpStatus.NO_CONTENT);
    }

    @GetMapping("query")
    public ResponseEntity<Student> getStudentByQuery(@RequestParam int id, @RequestParam String firstName){
        //select * from student where id = 1 and/or firstName  = "john"

        Student student = new Student(id, firstName, "Doe");
        return ResponseEntity.ok().body(student);
    }

}
