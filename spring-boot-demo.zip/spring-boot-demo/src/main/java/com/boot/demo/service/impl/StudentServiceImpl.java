package com.boot.demo.service.impl;

import com.boot.demo.service.StudentService;

public class StudentServiceImpl implements StudentService {
}
