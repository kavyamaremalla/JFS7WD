package com.example.thymeleaf.controller;

import com.example.thymeleaf.dto.EmployeeDto;
import com.example.thymeleaf.entity.Employee;
import com.example.thymeleaf.service.EmployeeService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;

    Logger logger = LoggerFactory.getLogger(EmployeeController.class);

    @GetMapping("/")
    public String viewHomePage(Model model){
        logger.trace("Trace");
        logger.info("Info Level");
        logger.debug("Debug level");
        logger.error("Error level");
        logger.warn("Warning level");
        model.addAttribute("allemplist", employeeService.getAllEmployees());
        logger.info("Completed save & returning back :" + model.getAttribute("allemplist"));
        return "index";
    }

    @GetMapping("/addnew")
    public String addNewEmployee(Model model){
        //map to dto & handle entity
        Employee employee = new Employee();
        model.addAttribute("employee", employee);
        return "newemployee";
    }

    @PostMapping("/save")
    public String saveEmployee(@ModelAttribute("employee")EmployeeDto employeeDto){
        employeeService.save(employeeDto);
        return "redirect:/";
    }

    @GetMapping("/showFormForUpdate/{id}")
    public String updateForm(@PathVariable(value = "id") long id, Model model){
        EmployeeDto employee = employeeService.getById(id);
        model.addAttribute("employee", employee);
        return "update";
    }

    @GetMapping("/deleteEmployee/{id}")
    public String deleteById(@PathVariable(value = "id") Long id){
        //map to dto & handle entity
        employeeService.deleteById(id);
        return "redirect:/";
    }

}
