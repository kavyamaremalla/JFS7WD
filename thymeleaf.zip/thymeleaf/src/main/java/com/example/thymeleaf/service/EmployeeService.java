package com.example.thymeleaf.service;

import com.example.thymeleaf.dto.EmployeeDto;
import com.example.thymeleaf.entity.Employee;

import java.util.List;

public interface EmployeeService {

    void save(EmployeeDto employeeDto);

    EmployeeDto getById(Long id);

    List<Employee> getAllEmployees();

    void deleteById(Long id);

    //update -> task
}
