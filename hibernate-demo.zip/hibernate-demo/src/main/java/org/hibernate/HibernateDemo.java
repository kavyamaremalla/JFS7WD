package org.hibernate;

import org.hibernate.cfg.Configuration;
import org.hibernate.models.Orders;
import org.hibernate.models.Persons;

public class HibernateDemo {
    public static void main(String[] args) {

        Configuration configuration = new Configuration().configure().addAnnotatedClass(Persons.class).addAnnotatedClass(Orders.class);

        SessionFactory sessionFactory = configuration.buildSessionFactory();

        Session session = sessionFactory.openSession();

        Transaction transaction = session.beginTransaction();


        Persons persons = session.get(Persons.class, 1);

        transaction.commit();

        persons.getOrders().stream().forEach(orders -> {
            System.out.println(orders.getOrderDetails());
        });
    }
}