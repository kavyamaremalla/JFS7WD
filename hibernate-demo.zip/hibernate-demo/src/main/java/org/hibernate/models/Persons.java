package org.hibernate.models;

import jakarta.persistence.*;
import lombok.Data;

import java.util.List;

@Entity
@Table(name = "persons")
@Data
public class Persons {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int personId;

    @Column(name = "FirstName", nullable = false, unique = true)
    private String firstName;

    @Column(name = "LastName")
    private String lastName;

    private Boolean isMarried;

    @OneToMany(mappedBy = "persons")
    private List<Orders> orders;
}
