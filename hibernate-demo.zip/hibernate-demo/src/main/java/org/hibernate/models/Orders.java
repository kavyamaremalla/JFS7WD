package org.hibernate.models;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "orders")
@Data
public class Orders {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int orderId;

    private int orderNumber;

    @Column(name = "personId", updatable = false, insertable = false)
    private int personId; //FK for orders & primary key for your persons table

    private String orderDetails;

    @ManyToOne
    @JoinColumn(name = "personId")
    private Persons persons;

    @Override
    public String toString() {
        return "Orders{" +
                "orderId=" + orderId +
                ", orderNumber=" + orderNumber +
                ", orderDetails='" + orderDetails + '\'' +
                '}';
    }
}
