package com.example.spring.jms.demo.dto;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class Email {

    private String to;

    private String body;

}
