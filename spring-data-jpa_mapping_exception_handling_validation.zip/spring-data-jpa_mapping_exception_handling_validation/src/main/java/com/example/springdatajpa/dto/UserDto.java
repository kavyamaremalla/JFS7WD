package com.example.springdatajpa.dto;

import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserDto {

    private Long id;

    @NotEmpty(message = "FirstName can't be null/empty")
    private String firstName;

    @NotEmpty(message = "LastName can't be null/empty")
    private String lastName;

    @NotEmpty(message = "Email can't be null/empty")
    private String email;
}
