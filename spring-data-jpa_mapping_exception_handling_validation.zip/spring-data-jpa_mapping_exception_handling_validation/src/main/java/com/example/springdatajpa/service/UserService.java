package com.example.springdatajpa.service;

import com.example.springdatajpa.dto.UserDto;

import java.util.List;

public interface UserService {

    UserDto createUser(UserDto userDto);

    List<UserDto> getAllUsers();

    UserDto getUserById(Long userId);

    UserDto updateUser(UserDto user);

    void deleteUser(Long userId);

}
