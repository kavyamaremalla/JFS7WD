package org.jdbc.example;

import com.mongodb.client.*;
import org.bson.Document;

public class MongoJDBCConnectivity {

    public static void main(String[] args) {

        MongoClient mongoClient = MongoClients.create("mongodb://localhost:27017");
        MongoDatabase database = mongoClient.getDatabase("schools");
        MongoCollection<Document> mongoCollection = database.getCollection("students");

        FindIterable<Document> studentCollection = mongoCollection.find();

        studentCollection.forEach(System.out::println);
    }
}
